<?php $__env->startSection('title', 'إدارة المستخدمين'); ?>
<?php $__env->startSection('content'); ?>

    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between align-items-center">
                <h6>جدول المستخدمين (<?php echo e($users->total()); ?>)</h6>

                <div class="d-flex align-items-center">
                    <!-- Button to Create New User -->
                    <a href="<?php echo e(route('dashboard.users.create')); ?>" class="btn btn-primary me-2">
                        إضافة مستخدم جديد
                    </a>

                    <!-- Dropdown for Export Options -->
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="exportDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            تصدير
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="exportDropdown">
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('dashboard.users.export', ['format' => 'excel'])); ?>">
                                    تصدير كـ Excel
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('dashboard.users.export', ['format' => 'pdf'])); ?>">
                                    تصدير كـ PDF
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Search and Filter Form -->
            <div class="card-header pb-0">
                <form action="<?php echo e(route('dashboard.users.index')); ?>" method="GET" class="row">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="البحث بالاسم أو اسم المستخدم" value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-3">
                        <select name="department_id" class="form-control">
                            <option value="">اختر القسم</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php echo e(request('department_id') == $department->id ? 'selected' : ''); ?>>
                                    <?php echo e($department->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="program_id" class="form-control">
                            <option value="">اختر البرنامج</option>
                            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($program->id); ?>" <?php echo e(request('program_id') == $program->id ? 'selected' : ''); ?>>
                                    <?php echo e($program->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">بحث</button>
                    </div>
                </form>
            </div>

            <div class="card-body px-0 pt-0 pb-2">
                <div class="table-responsive p-0">
                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">الإسم</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">الرتبة</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">تاريخ الإنضمام</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">القسم</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">البرنامج</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">عدد الأبحاث</th>
                                <th class="text-secondary opacity-7"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="d-flex px-2 py-1">
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-0 text-sm"><?php echo e($user->full_name); ?></h6>
                                            <p class="text-xs text-secondary mb-0"><?php echo e($user->username); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="align-middle">
                                    <?php if($user->role === 'user'): ?>
                                        <span class="text-secondary text-xs font-weight-bold">مستخدم</span>
                                    <?php elseif($user->role === 'admin'): ?>
                                        <span class="text-secondary text-xs font-weight-bold">مسؤول نظام</span>
                                    <?php elseif($user->role === 'committee_member'): ?>
                                        <span class="text-secondary text-xs font-weight-bold">عضو لجنة</span>
                                    <?php else: ?>
                                        <span class="badge badge-sm bg-gradient-danger">لم يتم الإختيار بعد</span>
                                    <?php endif; ?>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($user->created_at->format('Y/m/d h:i')); ?></span>
                                </td>
                                <td class="align-middle text-center text-sm">
                                    <?php if($user->department): ?>
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($user->department->name); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge-sm bg-gradient-danger">لم يتم الإختيار بعد</span>
                                    <?php endif; ?>
                                </td>
                                <td class="align-middle text-center text-sm">
                                    <?php if($user->program): ?>
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($user->program->name); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge-sm bg-gradient-danger">لم يتم الإختيار بعد</span>
                                    <?php endif; ?>
                                </td>
                                <td class="align-middle text-center text-sm">
                                    <span class="badge badge-sm bg-gradient-<?php echo e($user->researches_count > 0 ? 'success' : 'danger'); ?>"><?php echo e($user->researches_count); ?></span>
                                </td>
                                <td class="align-middle">
                                    <!-- Edit Link -->
                                    <a href="<?php echo e(route('dashboard.users.edit', $user->id)); ?>?page=<?php echo e(request('page')); ?>" class="text-info font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                        تعديل
                                    </a>

                                    <!-- Separator -->
                                    |

                                    <!-- Delete Form -->
                                    <form action="<?php echo e(route('dashboard.users.destroy', $user->id)); ?>" method="POST" style="display:inline;" id="delete-form-<?php echo e($user->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <a href="javascript:;" class="text-danger font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Delete user" onclick="confirmDelete(<?php echo e($user->id); ?>)">
                                            حذف
                                        </a>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                لا يوجد مستخدمين
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($users->appends(request()->query())->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
    function confirmDelete(userId) {
        if (confirm('هل تريد بالتأكيد حذف هذا المستخدم؟')) {
            document.getElementById('delete-form-' + userId).submit();
        }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/users/index.blade.php ENDPATH**/ ?>