<div class="card mb-4">
    <div class="card-header pb-0 d-flex justify-content-between align-items-center">
        <h6>جدول <?php echo e($title); ?> (<?php echo e($items->count()); ?>)</h6>
    </div>

    <div class="card-body px-0 pt-0 pb-2">
        <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
                <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e($column_name); ?></th>
                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">تاريخ الإنشاء</th>
                        <th class="text-secondary opacity-7"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="d-flex px-2 py-1">
                                <div class="d-flex flex-column justify-content-center">
                                    <h6 class="mb-0 text-sm"><?php echo e($item->value); ?></h6>
                                </div>
                            </div>
                        </td>
                        <td class="align-middle text-center">
                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($item->created_at->format('Y/m/d h:i')); ?></span>
                        </td>
                        <td class="align-middle">
                            <?php if($item): ?>
                            <form action="<?php echo e(route($delete_route, $item->id)); ?>" method="POST" style="display:inline;" id="delete-form-<?php echo e($item->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <a href="javascript:;" class="text-danger font-weight-bold text-xs" onclick="confirmDelete(<?php echo e($item->id); ?>)">
                                    حذف
                                </a>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="text-center">
                            <span class="text-muted">لا توجد بيانات لعرضها</span>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create New Item Form -->
    <div class="card-footer">
        <form action="<?php echo e(route($create_route)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">اسم <?php echo e($title); ?></label>
                <input type="text" name="value" id="name" class="form-control <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الاسم" value="<?php echo e(old('value')); ?>">

                <!-- Validation Error Message -->
                <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">إضافة <?php echo e($title); ?></button>
        </form>
    </div>
</div>

<script>
    function confirmDelete(itemId) {
        if (confirm('هل تريد بالتأكيد حذف هذا العنصر؟')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
<?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/adopt-research/table-form.blade.php ENDPATH**/ ?>