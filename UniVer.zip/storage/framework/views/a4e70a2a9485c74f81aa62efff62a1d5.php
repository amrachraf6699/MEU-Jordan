<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Researches Export</title>
    <style>
        body {
            font-family: 'XBRiyazRegular';
            font-weight: normal;
            font-style: normal;
            direction: rtl;
            text-align: right;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            text-align: right; /* Right align text */
            border: 1px solid #000;
        }
        th {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
        }

        .english-text {
            font-family: Arial, sans-serif;
        }

        @page {
        header: page-header;
        footer: page-footer;
        }

    </style>
</head>
<body>
    <htmlpageheader name="page-header">
        <img src="<?php echo e(public_path('logo.svg')); ?>" alt="Logo" width="200px">
    </htmlpageheader>

    <htmlpagefooter name="page-footer">
        <img src="<?php echo e(public_path('logo2.jpg')); ?>" alt="Logo" width="200px">
    </htmlpagefooter>



    <h2 style="margin-top: 50px">تفاصيل النتاجات البحثية</h2>
    <h5 style="margin-top: 10px">تم التصدير بواسطة: <?php echo e(auth()->user()->full_name); ?> في <?php echo e(now()->format('Y-m-d H:i:s')); ?></h5>


    <table>
        <thead>
            <tr>
                <th>العنوان</th>
                <th>النوع</th>
                <th>حالة النشر</th>
                <th>حالة الإعتماد</th>
                <th>اللغة</th>
                <th>تاريخ النشر</th>
                <th>الترتيب</th>
                <th>الأدلة</th>
                <th>الفهرسة</th>
                <th>المصادر</th>
                <th>فترة التوثيق</th>
                <th>السنة الأكاديمية</th>
                <th>الأولويات البحثية</th>
                <th>رابط المنشور البحثي</th>
                <th>اسم المستخدم</th>
                <th>الرقم الوظيفي</th>
                <th>قسم المستخدم</th>
                <th>برنامج المستخدم</th>
                <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                    <th>تم فك الإعتماد بواسطة</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $researches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($research->title); ?></td>
                    <td><?php echo e($research->type); ?></td>
                    <td><?php echo e($research->status); ?></td>
                    <td><?php echo e($research->accreditation_status); ?></td>
                    <td><?php echo e($research->language); ?></td>
                    <td><?php echo e($research->date_of_publication->format('Y/m/d')); ?></td>
                    <td><?php echo e($research->sort); ?></td>
                    <td class="english-text"><a href="<?php echo e(url($research->evidences)); ?>"> تحميــــل </a></td>
                    <td><?php echo e($research->indexing); ?></td>
                    <td class="english-text"><?php echo e($research->sources); ?></td>
                    <td><?php echo e($research->documentaion_period); ?></td>
                    <td><?php echo e($research->academic_year); ?></td>
                    <td><?php echo e($research->priority); ?></td>
                    <td><?php echo e($research->publication_link); ?></td>
                    <td><?php echo e($research->user->full_name ?? 'مستخدم محذوف'); ?></td>
                    <td><?php echo e($research->user->employee_number ?? '-'); ?></td>
                    <td><?php echo e($research->user->department->name ?? '-'); ?></td>
                    <td><?php echo e($research->user->program->name ?? '-'); ?></td>
                    <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                        <td><?php echo e($research->revokedBy->full_name ?? 'لم يتم فك الإعتماد بعد'); ?></td>
                    <?php endif; ?>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/researches/pdfs.blade.php ENDPATH**/ ?>