<?php $__env->startSection('title', 'الصفحة الرئيسية'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-3 col-sm-6 mb-lg-0 mb-4">
        <a href="<?php echo e(route('dashboard.users.index')); ?>">
            <div class="card">
            <div class="card-body p-3">
                <div class="row">
                <div class="col-8">
                    <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">عدد المستخدمين</p>
                    <h5 class="font-weight-bolder mb-0">
                        <?php echo e($users_count); ?>

                    </h5>
                    </div>
                </div>
                <div class="col-4 text-start">
                    <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
                    <i class="bx bxs-user text-lg opacity-10" aria-hidden="true"></i>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </a>
      </div>
      <div class="col-lg-3 col-sm-6 mb-lg-0 mb-4">
        <div class="card">
          <div class="card-body p-3">
            <div class="row">
              <div class="col-8">
                <div class="numbers">
                  <p class="text-sm mb-0 text-capitalize font-weight-bold">عدد الأقسام</p>
                  <h5 class="font-weight-bolder mb-0">
                    <?php echo e($departments_count); ?>

                  </h5>
                </div>
              </div>
              <div class="col-4 text-start">
                <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
                  <i class="bx bx-category text-lg opacity-10" aria-hidden="true"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-sm-6 mb-lg-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">عدد البرامج</p>
                    <h5 class="font-weight-bolder mb-0">
                      <?php echo e($programs_count); ?>

                    </h5>
                  </div>
                </div>
                <div class="col-4 text-start">
                  <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
                    <i class="bx bx-notepad text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      <div class="col-lg-3 col-sm-6 mb-lg-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">عدد الأبحاث</p>
                    <h5 class="font-weight-bolder mb-0">
                      <?php echo e($researches_count); ?>

                    </h5>
                  </div>
                </div>
                <div class="col-4 text-start">
                  <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
                    <i class="bx bx-file-blank text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
  </div>


  <div class="col-12 mt-4">
    <?php if($isProfileComplete): ?>
            <div class="alert alert-success">
                <strong>الملف الشخصي مكتمل!</strong> يمكنك البدء في استخدام النظام.
            </div>
    <?php else: ?>
    <div class="card mb-4">
        <div class="card-header pb-0">
            <h6>أكمل البيانات لتتمكن من رفع الأبحاث</h6>
        </div>
        <div class="card-body px-4 pt-4 pb-2">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="employee_number" class="form-label">الرقم الوظيفي</label>
                    <input type="text" name="employee_number" class="form-control" value="<?php echo e($user->employee_number); ?>" readonly>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">الرتبة</label>
                    <input type="text" name="role" class="form-control" value="<?php if($user->role == 'user'): ?> مستخدم
                    <?php elseif($user->role == 'admin'): ?> مدير نظام
                    <?php elseif($user->role == 'committee_member'): ?> عضو لجنة
                    <?php endif; ?>
                    " readonly>
                </div>
                <div class="mb-3">
                    <label for="department_id" class="form-label">القسم</label>
                    <select name="department_id" class="form-control" <?php echo e($user->department_id ? 'readonly' : ''); ?> >
                        <option value="">اختر القسم</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department->id); ?>" <?php echo e((old('department_id') == $department->id || $user->department_id == $department->id) ? 'selected' : ''); ?>>
                                <?php echo e($department->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger text-xs"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label for="program_id" class="form-label">البرنامج</label>
                    <select name="program_id" class="form-control" <?php echo e($user->program_id ? 'readonly' : ''); ?> >
                        <option value="">اختر البرنامج</option>
                        <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($program->id); ?>" <?php echo e((old('program_id') == $program->id || $user->program_id == $program->id) ? 'selected' : ''); ?>>
                                <?php echo e($program->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['program_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger text-xs"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary" <?php echo e($user->full_name && $user->employee_number && $user->role && $user->department_id && $user->program_id && $user->username ? 'disabled' : ''); ?>>
                        تحديث المعلومات
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/home.blade.php ENDPATH**/ ?>