<?php $__env->startSection('title', 'إدارة النتاجات البحثية'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between align-items-center">
                <h6>جدول النتاجات البحثية (<?php echo e($researches->total()); ?>)</h6>

                <div class="d-flex align-items-center">
                    <!-- Button to Create New User -->
                    <a href="<?php echo e(route('dashboard.researches.create')); ?>" class="btn btn-primary me-2">
                        إضافة نتاج بحثي جديد
                    </a>

                    <!-- Dropdown for Export Options -->
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="exportDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            تصدير
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="exportDropdown">
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('dashboard.researches.exportall', ['format' => 'excel'])); ?>">
                                    تصدير كـ Excel
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('dashboard.researches.exportall', ['format' => 'pdf'])); ?>">
                                    تصدير كـ PDF
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Search and Filter Form -->
            <div class="card" style="max-width: 100%; margin: auto;">
                <div class="card-body p-2">
                    <form action="<?php echo e(route('dashboard.researches.index')); ?>" method="GET" class="row g-2 align-items-center">

                        <!-- Search Input -->
                        <div class="col-auto">
                            <label for="search" class="form-label small mb-0">البحث بالعنوان</label>
                            <input type="text" name="search" id="search" class="form-control form-control-sm" placeholder="أدخل عنوان البحث" value="<?php echo e(request('search')); ?>">
                        </div>

                        <?php if(auth()->user()->role == 'admin'): ?>
                        <!-- Department Dropdown -->
                        <div class="col-auto">
                            <label for="department_id" class="form-label small mb-0">اختر القسم</label>
                            <select name="department_id" id="department_id" class="form-select form-select-sm">
                                <option value="">اختر القسم</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->id); ?>" <?php echo e(request('department_id') == $department->id ? 'selected' : ''); ?>>
                                        <?php echo e($department->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php endif; ?>

                        <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                        <!-- Department Dropdown -->
                        <div class="col-auto">
                            <label for="program_id" class="form-label small mb-0">اختر البرنامج</label>
                            <select name="program_id" id="program_id" class="form-select form-select-sm">
                                <option value="">اختر البرنامج</option>
                                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($program->id); ?>" <?php echo e(request('program_id') == $program->id ? 'selected' : ''); ?>>
                                        <?php echo e($program->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php endif; ?>

                        <!-- Status Dropdown -->
                        <div class="col-auto">
                            <label for="status" class="form-label small mb-0">اختر حالة النشر</label>
                            <select name="status" id="status" class="form-select form-select-sm">
                                <option value="">اختر حالة النشر</option>
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status->value); ?>" <?php echo e(request('status') == $status->value ? 'selected' : ''); ?>>
                                        <?php echo e($status->value); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Accreditation Status Dropdown -->
                        <div class="col-auto">
                            <label for="accreditation_status" class="form-label small mb-0">اختر حالة الإعتماد</label>
                            <select name="accreditation_status" id="accreditation_status" class="form-select form-select-sm">
                                <option value="">اختر حالة الإعتماد</option>
                                <option value="معلق" <?php echo e(request('accreditation_status') == 'معلق' ? 'selected' : ''); ?>>معلق</option>
                                <option value="معتمد" <?php echo e(request('accreditation_status') == 'معتمد' ? 'selected' : ''); ?>>معتمد</option>
                            </select>
                        </div>

                        <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                        <!-- My Researches Checkbox -->
                        <div class="col-auto">
                            <div class="form-check form-check-inline mt-4">
                                <input type="checkbox" name="my_researches" id="my_researches" class="form-check-input" <?php echo e(request('my_researches') ? 'checked' : ''); ?>>
                                <label for="my_researches" class="form-check-label small">نتاجاتي البحثية</label>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Submit Button -->
                        <div class="col-auto mt-5">
                            <button type="submit" class="btn btn-primary btn-sm">بحث</button>
                        </div>

                    </form>
                </div>
            </div>


            <div class="card-body px-0 pt-0 pb-2">
                <div class="table-responsive p-0">
                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">العنوان</th>
                                <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">المستخدم</th>
                                <?php endif; ?>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">النوع</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">الحالة</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">اللغة</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">المصدر</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">الفهرسة</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">تاريخ النشر</th>
                                <th class="text-secondary opacity-7"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $researches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="d-flex px-2 py-1">
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-0 text-sm"><?php echo e($research->title); ?></h6>
                                            <p class="text-xs text-secondary mb-0"><?php echo e($research->academic_year); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                                <td class="align-middle text-center">
                                    <?php if($research->user): ?>
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->user->full_name); ?></span>
                                    <?php else: ?>
                                    <span class="text-danger text-xs font-weight-bold">مستخدم محذوف</span>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->type); ?></span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-primary text-xs font-weight-bold"><?php echo e($research->status); ?>/<?php echo e($research->accreditation_status); ?></span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->language); ?></span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->sources); ?></span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->indexing); ?></span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->date_of_publication->format('Y-m-d')); ?></span>
                                </td>
                                <td class="align-middle">
                                        <?php if($research->accreditation_status !== 'معتمد'): ?>
                                            <?php if(auth()->id() == $research->user_id || auth()->user()->role == 'admin'): ?>

                                                <!-- Edit Link -->
                                                <a href="<?php echo e(route('dashboard.researches.edit', $research)); ?>" class="text-info font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                                    تعديل
                                                </a>

                                                <!-- Separator -->
                                                |

                                                <!-- Delete Form -->
                                                <form action="<?php echo e(route('dashboard.researches.destroy', $research->id)); ?>" method="POST" style="display:inline;" id="delete-form-<?php echo e($research->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <a href="javascript:;" class="text-danger font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Delete user" onclick="confirmDelete(<?php echo e($research->id); ?>)">
                                                        حذف
                                                    </a>
                                                </form>

                                                <!-- Separator -->
                                                |

                                                <!-- Approve Link -->
                                                <a href="<?php echo e(route('dashboard.researches.approve', $research)); ?>" class="text-success font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Approve user">
                                                    إعتماد
                                                </a>


                                            <!-- Separator -->
                                            |

                                            <?php endif; ?>


                                            <!-- Show Link -->
                                            <a href="<?php echo e(route('dashboard.researches.show', $research)); ?>" class="text-info font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                                عرض
                                            </a>

                                            |
                                            <!-- Export to PDF Link with Icon -->
                                            <a href="<?php echo e(route('dashboard.researches.export', ['research' => $research->id, 'type' => 'pdf'])); ?>" class="text-danger font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Export to Excel">
                                                PDF
                                            </a>
                                        <?php else: ?>
                                            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                                            <a href="<?php echo e(route('dashboard.researches.revoke', $research)); ?>" class="text-primary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                                فك الإعتماد
                                            </a>
                                            |
                                            <?php endif; ?>
                                            <!-- Show Link -->
                                            <a href="<?php echo e(route('dashboard.researches.show', $research)); ?>" class="text-info font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                                عرض
                                            </a>


                                            |
                                            <!-- Export to PDF Link with Icon -->
                                            <a href="<?php echo e(route('dashboard.researches.export', ['research' => $research->id, 'type' => 'pdf'])); ?>" class="text-danger font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Export to Excel">
                                                PDF
                                            </a>
                                        <?php endif; ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                لا توجد أبحاث
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($researches->appends(request()->query())->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(researchId) {
        if (confirm('هل تريد بالتأكيد حذف هذا البحث؟')) {
            document.getElementById('delete-form-' + researchId).submit();
        }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/researches/index.blade.php ENDPATH**/ ?>