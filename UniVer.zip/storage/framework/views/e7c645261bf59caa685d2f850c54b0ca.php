<?php $__env->startSection('title', 'إدارة النتاجات البحثية'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between align-items-center">
                <h6>جدول النتاجات البحثية (<?php echo e($researches->total()); ?>)</h6>

                <!-- Button to Create New Research -->
                <a href="<?php echo e(route('dashboard.researches.create')); ?>" class="btn btn-primary">
                    إضافة نتاج بحثي جديد
                </a>
            </div>

            <!-- Search and Filter Form -->
            <div class="card-header pb-0">
                <form action="<?php echo e(route('dashboard.researches.index')); ?>" method="GET" class="row">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="البحث بالعنوان" value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-3">
                        <select name="department_id" class="form-control">
                            <option value="">اختر القسم</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php echo e(request('department_id') == $department->id ? 'selected' : ''); ?>>
                                    <?php echo e($department->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="status" class="form-control">
                            <option value="">اختر الحالة</option>
                            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>معلق</option>
                            <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>مُعتمد</option>
                            <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>مرفوض/محذوف</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">بحث</button>
                    </div>
                </form>
            </div>

            <div class="card-body px-0 pt-0 pb-2">
                <div class="table-responsive p-0">
                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">العنوان</th>
                                <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">المستخدم</th>
                                <?php endif; ?>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">النوع</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">الحالة</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">اللغة</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">المصدر</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">الفهرسة</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">تاريخ النشر</th>
                                <th class="text-secondary opacity-7"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $researches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="d-flex px-2 py-1">
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-0 text-sm"><?php echo e($research->title); ?></h6>
                                            <p class="text-xs text-secondary mb-0"><?php echo e($research->academic_year); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->user->full_name); ?></span>
                                </td>
                                <?php endif; ?>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->type); ?></span>
                                </td>
                                <td class="align-middle text-center">
                                    <?php if($research->status === 'pending'): ?>
                                        <span class="text-warning text-xs font-weight-bold">معلق</span>
                                    <?php elseif($research->status === 'approved'): ?>
                                        <span class="text-success text-xs font-weight-bold">مٌعتمد</span>
                                    <?php elseif($research->status === 'rejected'): ?>
                                        <span class="text-danger text-xs font-weight-bold">مرفوض/محذوف</span>
                                    <?php endif; ?>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->language); ?></span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->sources); ?></span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($research->indexing); ?></span>
                                </td>
                                <td class="align-middle">
                                        <?php if($research->status === 'pending'): ?>
                                            <!-- Edit Link -->
                                            <a href="<?php echo e(route('dashboard.researches.edit', $research)); ?>" class="text-info font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                                تعديل
                                            </a>

                                            <!-- Separator -->
                                            |

                                            <!-- Delete Form -->
                                            <form action="<?php echo e(route('dashboard.researches.destroy', $research->id)); ?>" method="POST" style="display:inline;" id="delete-form-<?php echo e($research->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a href="javascript:;" class="text-danger font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Delete user" onclick="confirmDelete(<?php echo e($research->id); ?>)">
                                                    حذف
                                                </a>
                                            </form>

                                            <!-- Separator -->
                                            |

                                            <!-- Approve Link -->
                                            <a href="<?php echo e(route('dashboard.researches.approve', $research)); ?>" class="text-success font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Approve user">
                                                إعتماد
                                            </a>

                                            <!-- Separator -->
                                            |

                                            <!-- Show Link -->
                                            <a href="<?php echo e(route('dashboard.researches.show', $research)); ?>" class="text-info font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                                عرض
                                            </a>

                                            <!-- Separator -->
                                            |

                                            <a href="<?php echo e(route('dashboard.researches.export', ['research' => $research->id, 'type' => 'excel'])); ?>" class="text-success font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Export to Excel">
                                                Excel
                                            </a>

                                            |
                                            <!-- Export to PDF Link with Icon -->
                                            <a href="<?php echo e(route('dashboard.researches.export', ['research' => $research->id, 'type' => 'pdf'])); ?>" class="text-danger font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Export to Excel">
                                                PDF
                                            </a>
                                        <?php else: ?>
                                            <?php if(auth()->user()->role == 'admin'): ?>
                                            <a href="<?php echo e(route('dashboard.researches.revoke', $research)); ?>" class="text-primary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                                فك الإعتماد
                                            </a>
                                            |
                                            <?php endif; ?>
                                            <!-- Show Link -->
                                            <a href="<?php echo e(route('dashboard.researches.show', $research)); ?>" class="text-info font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                                عرض
                                            </a>

                                            <!-- Separator -->
                                            |

                                            <!-- Export to Excel Link with Icon -->
                                            <a href="<?php echo e(route('dashboard.researches.export', ['research' => $research->id, 'type' => 'excel'])); ?>" class="text-success font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Export to Excel">
                                                Excel
                                            </a>

                                            |
                                            <!-- Export to PDF Link with Icon -->
                                            <a href="<?php echo e(route('dashboard.researches.export', ['research' => $research->id, 'type' => 'pdf'])); ?>" class="text-danger font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Export to Excel">
                                                PDF
                                            </a>
                                        <?php endif; ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                لا توجد أبحاث
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($researches->appends(request()->query())->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(researchId) {
        if (confirm('هل تريد بالتأكيد حذف هذا البحث؟')) {
            document.getElementById('delete-form-' + researchId).submit();
        }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/researches/index.blade.php ENDPATH**/ ?>