<?php $__env->startSection('title', 'نشاطات المستخدم'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header pb-0">
                <h6>نشاطات المستخدم</h6>
            </div>

            <div class="card-body px-4 pt-4 pb-2" style="max-height: 400px; overflow-y: auto;">
                <!-- User Activity List -->
                <div class="list-group">
                    <?php if($activities->isEmpty()): ?>
                        <p class="text-center text-muted">لا توجد نشاطات لعرضها</p>
                    <?php else: ?>
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($activity->activity); ?></h6>
                                        <small class="text-muted">
                                            <?php echo e(\Carbon\Carbon::parse($activity->created_at)->locale('ar')->translatedFormat('l Y-m-d H:i:s')); ?>

                                        </small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Pagination Links -->
            <div class="card-footer text-center">
                <?php echo e($activities->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/activities.blade.php ENDPATH**/ ?>