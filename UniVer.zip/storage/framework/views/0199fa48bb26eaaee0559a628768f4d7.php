<?php $__env->startSection('title', 'نشاطات المستخدم'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header pb-0">
                <h6>نشاطات المستخدم</h6>
            </div>

            <div class="card-header pb-0">
                <form action="" method="GET" class="row">
                    <div class="col-md-3">
                        <label for="user_id">المستخدم:</label>
                        <select class="form-control" name="user_id" id="user_id">
                            <option value="">جميع المستخدمين</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"
                                <?php if(request()->get('user_id') == $user->id): ?> selected <?php endif; ?>>
                                    <?php echo e($user->full_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="from_date">من تاريخ:</label>
                        <input type="date" class="form-control" id="from_date" name="from_date" value="<?php echo e(request()->get('from_date')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="to_date">إلى تاريخ:</label>
                        <input type="date" class="form-control" id="to_date" name="to_date" value="<?php echo e(request()->get('to_date')); ?>">
                    </div>
                    <div class="col-md-2 mt-4">
                        <button type="submit" class="btn btn-primary w-100">بحث</button>
                    </div>
                </form>
            </div>
            <div class="card-body px-4 pt-4 pb-2">
                <div class="list-group" style="max-height: 400px; overflow-y: auto;">
                    <?php if($activities->isEmpty()): ?>
                        <p class="text-center text-muted">لا توجد نشاطات لعرضها</p>
                    <?php else: ?>
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item mb-3 activity-item">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="activity-details">
                                    <small class="mb-1"><?php echo e($activity->activity); ?></small>
                                    <small class="text-muted">
                                        (<?php echo e(\Carbon\Carbon::parse($activity->created_at)->locale('ar')->translatedFormat('l Y-m-d H:i:s')); ?>)
                                    </small>
                                </div>
                                
                                <div class="activity-user">
                                    <small class="mb-1"><?php echo e($activity->user->full_name); ?></small>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card-footer text-center">
                <?php echo e($activities->appends(request()->query())->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/users-activities.blade.php ENDPATH**/ ?>