<?php $__env->startSection('title', 'إضافة نتاج بحثي جديد'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header pb-0">
                <h6>إضافة نتاج بحثي جديد</h6>
            </div>

            <div class="card-body">
                <!-- Research Create Form -->
                <form action="<?php echo e(route('dashboard.researches.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <!-- Title -->
                    <div class="form-group">
                        <label for="title">عنوان النتاج البحثي</label>
                        <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder="أدخل عنوان النتاج البحثي" required>
                        <small class="form-text text-muted"><?php echo e($hints->title); ?></small>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Type (Dropdown) -->
                    <div class="form-group">
                        <label for="type">نوع النتاج البحثي</label>
                        <select name="type" id="type" class="form-control" required>
                            <option value="">اختر نوع النتاج البحثي</option>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->value); ?>" <?php echo e(old('type') == $type->value ? 'selected' : ''); ?>><?php echo e($type->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="form-text text-muted"><?php echo e($hints->type); ?></small>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Status (Dropdown) -->
                    <div class="form-group">
                        <label for="status">حالة النشر</label>
                        <select name="status" id="status" class="form-control" required>
                            <option value="">اختر حالة النشر</option>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status->value); ?>" <?php echo e(old('status') == $status->value ? 'selected' : ''); ?>><?php echo e($status->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="form-text text-muted"><?php echo e($hints->status); ?></small>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Language (Dropdown) -->
                    <div class="form-group">
                        <label for="language">لغة النشر</label>
                        <select name="language" id="language" class="form-control" required>
                            <option value="">اختر لغة النشر</option>
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($language->value); ?>" <?php echo e(old('language') == $language->value ? 'selected' : ''); ?>><?php echo e($language->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="form-text text-muted"><?php echo e($hints->language); ?></small>
                        <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Date of Publication -->
                    <div class="form-group">
                        <label for="date_of_publication">تاريخ النشر</label>
                        <input type="date" name="date_of_publication" id="date_of_publication" class="form-control" value="<?php echo e(old('date_of_publication')); ?>" required>
                        <small class="form-text text-muted"><?php echo e($hints->date_of_publication); ?></small>
                        <?php $__errorArgs = ['date_of_publication'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Sort (Dropdown) -->
                    <div class="form-group">
                        <label for="sort">ترتيب المباحث</label>
                        <select name="sort" id="sort" class="form-control" required>
                            <option value="">اختر ترتيب المباحث</option>
                            <?php $__currentLoopData = ['منفرد', 'باحث أول', 'باحث ثاني', 'باحث ثالث', 'أكثر من ثالث']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sortOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sortOption); ?>" <?php echo e(old('sort') == $sortOption ? 'selected' : ''); ?>><?php echo e($sortOption); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="form-text text-muted"><?php echo e($hints->sort); ?></small>
                        <?php $__errorArgs = ['sort'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Sources -->
                    <div class="form-group">
                        <label for="sources">مصدر النتاج البحثي</label>
                        <input type="text" name="sources" id="sources" class="form-control" value="<?php echo e(old('sources')); ?>" placeholder="أدخل مصدر النتاج البحثي" required>
                        <small class="form-text text-muted"><?php echo e($hints->sources); ?></small>
                        <?php $__errorArgs = ['sources'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Indexing (Dropdown) -->
                    <div class="form-group">
                        <label for="indexing">الفهرسة</label>
                        <select name="indexing[]" id="indexing" class="form-control" required multiple>
                            <?php $__currentLoopData = $indexings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($indexing->value); ?>" <?php echo e(old('indexing') == $indexing->value ? 'selected' : ''); ?>><?php echo e($indexing->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="form-text text-muted"><?php echo e($hints->indexing); ?></small>
                        <?php $__errorArgs = ['indexing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Evidences (File Upload) -->
                    <div class="form-group">
                        <label for="evidences">تحميل الشواهد</label>
                        <input type="file" name="evidences" id="evidences" class="form-control" multiple>
                        <small class="form-text text-muted"><?php echo e($hints->evidences); ?></small>
                        <?php $__errorArgs = ['evidences'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Documentation Period (Dropdown) -->
                    <div class="form-group">
                        <label for="documentaion_period">فترة التوثيق</label>
                        <select name="documentaion_period" id="documentaion_period" class="form-control" required>
                            <option value="">اختر فترة التوثيق</option>
                            <?php $__currentLoopData = $documentaion_periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($period->value); ?>" <?php echo e(old('documentaion_period') == $period->value ? 'selected' : ''); ?>><?php echo e($period->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="form-text text-muted"><?php echo e($hints->documentaion_period); ?></small>
                        <?php $__errorArgs = ['documentaion_period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Academic Year (Dropdown) -->
                    <div class="form-group">
                        <label for="academic_year">العام الأكاديمي</label>
                        <select name="academic_year" id="academic_year" class="form-control" required>
                            <option value="">اختر العام الأكاديمي</option>
                            <?php $__currentLoopData = $academic_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academic_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($academic_year->value); ?>" <?php echo e(old('academic_year') == $academic_year->value ? 'selected' : ''); ?>><?php echo e($academic_year->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="form-text text-muted"><?php echo e($hints->academic_year); ?></small>
                        <?php $__errorArgs = ['academic_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-primary">إضافة نتاج بحثي جديد</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/researches/create.blade.php ENDPATH**/ ?>