<?php $__env->startSection('title', 'تفاصيل البحث'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mx-auto mt-4">
    <div class="card mb-4 shadow-lg rounded-lg">
        <div class="card-header bg-blue-600 text-white rounded-t-lg">
            <h6 class="text-lg font-semibold">تفاصيل البحث: <?php echo e($research->title); ?></h6>
        </div>
        <div class="card-body p-6">

            <!-- Main Research Information -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div class="bg-gray-100 p-4 rounded-lg shadow">
                    <h5 class="font-bold text-lg mb-2">معلومات البحث الأساسية</h5>
                    <p><strong>عنوان البحث:</strong> <?php echo e($research->title); ?></p>
                    <p><strong>نوع البحث:</strong> <?php echo e($research->type); ?></p>
                    <p><strong>اللغة:</strong> <?php echo e($research->language); ?></p>
                    <p><strong>ترتيب المباحث:</strong> <?php echo e($research->sort); ?></p>
                    <p><strong>الفهرسة:</strong> <?php echo e($research->indexing); ?></p>
                    <p><strong>المصادر:</strong> <?php echo e($research->sources); ?></p>
                    <p><strong>الأولوية البحثية:</strong> <?php echo e($research->priority); ?></p>
                    <?php if($research->publication_link): ?>
                    <p><strong>رابط المنشور البحثي:</strong> <a href="<?php echo e($research->publication_link); ?>" target="_blank" class="text-blue-600 hover:underline"><?php echo e($research->publication_link); ?></a></p>
                    <?php endif; ?>

                    <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'committee_member'): ?>
                    <p><strong>تم فك الإعتماد بواسطة:</strong> <?php echo e($research->revokedBy->full_name ?? 'لم يتم فك الإعتماد بعد'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="bg-gray-100 p-4 rounded-lg shadow">
                    <h5 class="font-bold text-lg mb-2">تواريخ مهمة</h5>
                    <p><strong>السنة الأكاديمية:</strong> <?php echo e($research->academic_year); ?></p>
                    <p><strong>تاريخ النشر:</strong> <?php echo e($research->date_of_publication->format('Y-m-d')); ?></p>
                    <p><strong> فترة التوثيق:</strong> <?php echo e($research->documentaion_period); ?></p>
                </div>
            </div>

            <!-- User Information -->
            <div class="bg-gray-100 p-4 rounded-lg shadow mb-8">
                <h5 class="font-bold text-lg mb-2">تم التقديم بواسطة</h5>
                <p><strong>الاسم:</strong> <?php echo e($research->user->full_name ?? 'مستخدم محذوف'); ?></p>
                <p><strong> اسم المستخدم:</strong> <?php echo e($research->user->username ?? 'مستخدم محذوف'); ?></p>
            </div>

            <!-- Evidences Section -->
            <div class="bg-gray-100 p-4 rounded-lg shadow mb-8">
                <h5 class="font-bold text-lg mb-2">الشواهد</h5>
                <?php if($research->evidences): ?>
                    <a href="<?php echo e(asset('storage/' . $research->evidences)); ?>" class="text-blue-600 hover:underline">
                        تحميل الشواهد
                    </a>
                <?php else: ?>
                    <p class="text-red-500">لا توجد شواهد متاحة.</p>
                <?php endif; ?>
            </div>

            <!-- Back Button -->
            <div class="text-center">
                <a href="<?php echo e(route('dashboard.researches.index')); ?>" class="btn btn-primary">
                    العودة إلى قائمة الأبحاث
                </a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/researches/show.blade.php ENDPATH**/ ?>