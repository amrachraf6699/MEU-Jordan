<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Importing Cairo font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif; /* Applying Cairo font */
        }
    </style>
</head>

<body class="bg-gray-50 flex flex-col min-h-screen">
    <!-- Header -->
    <header class="relative p-4 bg-white shadow-lg flex items-center justify-center">
        <!-- Left Image -->
        <img src="<?php echo e(asset('logo.svg')); ?>" alt="Logo 1" class="hidden md:block absolute left-4 h-10">

        <!-- Centered Text -->
        <div class="text-center">
            <h1 class="text-sm font-bold">جامعة الشرق الأوسط - كلية الآداب و العلوم التربوية</h1>
        </div>

        <!-- Right Image -->
        <img src="<?php echo e(asset('logo2.jpg')); ?>" alt="Logo 2" class="absolute right-4 h-10">
    </header>


    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer -->
    <footer class="bg-gray-200 text-center p-4">
        <p class="text-sm text-gray-600">&copy; إعداد الدكتور: أحمد عبدالسميع طبية</p>
    </footer>
</body>

</html>
<?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/layouts/app.blade.php ENDPATH**/ ?>