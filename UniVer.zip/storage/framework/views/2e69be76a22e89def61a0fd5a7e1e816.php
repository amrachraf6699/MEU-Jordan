<?php $__env->startSection('title', 'إنشاء مستخدم جديد'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header pb-0">
                <h6>إنشاء مستخدم جديد</h6>
            </div>

            <div class="card-body px-0 pt-0 pb-2">
                <!-- Create User Form -->
                <form action="<?php echo e(route('dashboard.users.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="row p-4">
                        <!-- Full Name Field -->
                        <div class="col-md-6 mb-3">
                            <label for="full_name" class="form-label">الإسم الكامل</label>
                            <input type="text" name="full_name" class="form-control" value="<?php echo e(old('full_name')); ?>">
                            <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger text-xs"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Username Field -->
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">اسم المستخدم</label>
                            <input type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>">
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger text-xs"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Employee Number Field -->
                        <div class="col-md-6 mb-3">
                            <label for="employee_number" class="form-label">الرقم الوظيفي</label>
                            <input type="number" name="employee_number" class="form-control" value="<?php echo e(old('employee_number')); ?>">
                            <?php $__errorArgs = ['employee_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger text-xs"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Role Field -->
                        <div class="col-md-6 mb-3">
                            <label for="role" class="form-label">الرتبة</label>
                            <select name="role" class="form-control">
                                <option value="">اختر الرتبة</option>
                                <option value="user" <?php echo e(old('role') == 'user' ? 'selected' : ''); ?>>مستخدم</option>
                                <option value="admin" <?php echo e(old('role') == 'admin' ? 'selected' : ''); ?>>مدير نظام</option>
                                <option value="committee_member" <?php echo e(old('role') == 'committee_member' ? 'selected' : ''); ?>>عضو لجنة</option>
                            </select>
                            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger text-xs"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Department Field -->
                        <div class="col-md-6 mb-3">
                            <label for="department_id" class="form-label">القسم</label>
                            <select name="department_id" class="form-control">
                                <option value="">اختر القسم</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->id); ?>" <?php echo e(old('department_id') == $department->id ? 'selected' : ''); ?>>
                                        <?php echo e($department->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger text-xs"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Program Field -->
                        <div class="col-md-6 mb-3">
                            <label for="program_id" class="form-label">البرنامج</label>
                            <select name="program_id" class="form-control">
                                <option value="">اختر البرنامج</option>
                                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($program->id); ?>" <?php echo e(old('program_id') == $program->id ? 'selected' : ''); ?>>
                                        <?php echo e($program->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['program_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger text-xs"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 text-center">
                            <div class="d-flex justify-content-center mt-2 mb-2">
                                <button type="submit" class="btn btn-primary me-2">إضافة المستخدم</button>

                                <a href="<?php echo e(route('dashboard.users.import')); ?>" class="btn btn-secondary">استيراد من Excel</a>
                            </div>
                            <small class="form-text text-muted mt-2 p-2 border border-2 border-round border-rounded">كلمة المرور الافتراضية هي الرقم الوظيفي</small>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/users/create.blade.php ENDPATH**/ ?>