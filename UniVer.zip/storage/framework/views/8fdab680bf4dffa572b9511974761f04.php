<?php $__env->startSection('title', 'تعديل البحث'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header pb-0">
                <h6>تعديل البحث: <?php echo e($research->title); ?></h6>
            </div>

            <div class="card-body">
                <!-- Research Edit Form -->
                <form action="<?php echo e(route('dashboard.researches.update', $research->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Title -->
                    <div class="form-group">
                        <label for="title">عنوان البحث</label>
                        <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title', $research->title)); ?>" placeholder="أدخل عنوان البحث" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Type -->
                    <div class="form-group">
                        <label for="type">نوع البحث</label>
                        <input type="text" name="type" id="type" class="form-control" value="<?php echo e(old('type', $research->type)); ?>" placeholder="أدخل نوع البحث" required>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Language -->
                    <div class="form-group">
                        <label for="language">اللغة</label>
                        <input type="text" name="language" id="language" class="form-control" value="<?php echo e(old('language', $research->language)); ?>" placeholder="أدخل اللغة" required>
                        <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Date of Publication -->
                    <div class="form-group">
                        <label for="date_of_publication">تاريخ النشر</label>
                        <input type="date" name="date_of_publication" id="date_of_publication" class="form-control" value="<?php echo e(old('date_of_publication', optional($research->date_of_publication)->format('Y-m-d'))); ?>" required>
                        <?php $__errorArgs = ['date_of_publication'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Sort -->
                    <div class="form-group">
                        <label for="sort">ترتيب المباحث</label>
                        <input type="text" name="sort" id="sort" class="form-control" value="<?php echo e(old('sort', $research->sort)); ?>" placeholder="أدخل ترتيب المباحث" required>
                        <?php $__errorArgs = ['sort'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Evidences (File Upload) -->
                    <div class="form-group">
                        <label for="evidences">الشواهد</label>
                        <input type="file" name="evidences" id="evidences" class="form-control">
                        <small>يمكنك تحميل ملفات جديدة إذا رغبت.</small>
                        <?php $__errorArgs = ['evidences'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Indexing -->
                    <div class="form-group">
                        <label for="indexing">الفهرسة</label>
                        <input type="text" name="indexing" id="indexing" class="form-control" value="<?php echo e(old('indexing', $research->indexing)); ?>" placeholder="أدخل الفهرسة" required>
                        <?php $__errorArgs = ['indexing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Sources -->
                    <div class="form-group">
                        <label for="sources">المصادر</label>
                        <input type="text" name="sources" id="sources" class="form-control" value="<?php echo e(old('sources', $research->sources)); ?>" placeholder="أدخل المصادر" required>
                        <?php $__errorArgs = ['sources'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Documentation Period Start -->
                    <div class="form-group">
                        <label for="documentaion_period_start">بداية فترة التوثيق</label>
                        <input type="date" name="documentaion_period_start" id="documentaion_period_start" class="form-control" value="<?php echo e(old('documentaion_period_start', optional($research->documentaion_period_start)->format('Y-m-d'))); ?>" required>
                        <?php $__errorArgs = ['documentaion_period_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Documentation Period End -->
                    <div class="form-group">
                        <label for="documentaion_period_end">نهاية فترة التوثيق</label>
                        <input type="date" name="documentaion_period_end" id="documentaion_period_end" class="form-control" value="<?php echo e(old('documentaion_period_end', optional($research->documentaion_period_end)->format('Y-m-d'))); ?>" required>
                        <?php $__errorArgs = ['documentaion_period_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Academic Year -->
                    <div class="form-group">
                        <label for="academic_year">السنة الأكاديمية</label>
                        <input type="text" name="academic_year" id="academic_year" class="form-control" value="<?php echo e(old('academic_year', $research->academic_year)); ?>" placeholder="أدخل السنة الأكاديمية" required>
                        <?php $__errorArgs = ['academic_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Submit Button -->
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">تحديث البحث</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/dashboard/researches/edit.blade.php ENDPATH**/ ?>