
<?php $__env->startSection('title', 'التسجيل'); ?>
<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<main class="flex-grow flex flex-col items-center justify-center text-center p-6">
    <h1 class="text-4xl font-bold text-gray-800 mb-4">إنشاء حساب جديد</h1>
    
    <p class="text-xs text-gray-600 mb-6">يرجى ملء التفاصيل الخاصة بك.</p>

    <form action="" method="POST" class="w-full max-w-md">
        <?php echo csrf_field(); ?>
        
        <div class="mb-4">
            <label for="full_name" class="block text-left text-gray-700 mb-2">الاسم الثلاثي</label>
            <input type="text" id="full_name" name="full_name" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-400 <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الاسم الثلاثي" value="<?php echo e(old('full_name')); ?>">
            <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4">
            <label for="employee_number" class="block text-left text-gray-700 mb-2">الرقم الوظيفي</label>
            <input type="text" id="employee_number" name="employee_number" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-400 <?php $__errorArgs = ['employee_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الرقم الوظيفي" value="<?php echo e(old('employee_number')); ?>">
            <?php $__errorArgs = ['employee_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4">
            <label for="password" class="block text-left text-gray-700 mb-2">كلمة السر</label>
            <input type="password" id="password" name="password" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-400 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="كلمة السر">
            <p class="text-sm text-gray-500 mt-1">يرجى حفظ كلمة السر لتسجيل الدخول بها فيما بعد.</p>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4">
            <label for="rank" class="block text-left text-gray-700 mb-2">الرتبة</label>
            <select id="rank" name="rank" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-400 <?php $__errorArgs = ['rank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="" disabled selected>اختر الرتبة</option>
                <option value="مدير" <?php echo e(old('rank') == 'مدير' ? 'selected' : ''); ?>>مدير</option>
                <option value="نائب مدير" <?php echo e(old('rank') == 'نائب مدير' ? 'selected' : ''); ?>>نائب مدير</option>
                <option value="موظف" <?php echo e(old('rank') == 'موظف' ? 'selected' : ''); ?>>موظف</option>
            </select>
            <?php $__errorArgs = ['rank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4">
            <label for="department" class="block text-left text-gray-700 mb-2">القسم</label>
            <select id="department" name="department" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-400 <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="" disabled selected>اختر القسم</option>
                <option value="التقنية" <?php echo e(old('department') == 'التقنية' ? 'selected' : ''); ?>>التقنية</option>
                <option value="الإدارة" <?php echo e(old('department') == 'الإدارة' ? 'selected' : ''); ?>>الإدارة</option>
                <option value="البحث العلمي" <?php echo e(old('department') == 'البحث العلمي' ? 'selected' : ''); ?>>البحث العلمي</option>
            </select>
            <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-6">
            <label for="program" class="block text-left text-gray-700 mb-2">البرنامج</label>
            <select id="program" name="program" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-400 <?php $__errorArgs = ['program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="" disabled selected>اختر البرنامج</option>
                <option value="برنامج 1" <?php echo e(old('program') == 'برنامج 1' ? 'selected' : ''); ?>>برنامج 1</option>
                <option value="برنامج 2" <?php echo e(old('program') == 'برنامج 2' ? 'selected' : ''); ?>>برنامج 2</option>
                <option value="برنامج 3" <?php echo e(old('program') == 'برنامج 3' ? 'selected' : ''); ?>>برنامج 3</option>
            </select>
            <?php $__errorArgs = ['program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-blue-700 transition duration-200 w-full">إنشاء حساب</button>
    </form>

    <p class="text-gray-600 mt-4">لديك حساب بالفعل؟ <a href="<?php echo e(route('login')); ?>" class="text-blue-600 hover:underline">تسجيل الدخول</a></p>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amr Achraf\Desktop\UniVer\resources\views/auth/signup.blade.php ENDPATH**/ ?>